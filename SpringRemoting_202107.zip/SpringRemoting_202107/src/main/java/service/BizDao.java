package service;

public interface BizDao {

	public SerializableResponse getBizRequest(SerializableRequest b) 
			throws DAOException;
	
}
