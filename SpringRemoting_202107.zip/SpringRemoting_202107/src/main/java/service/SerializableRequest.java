package service;

import java.io.Serializable;
import static java.lang.String.format;

public class SerializableRequest implements Serializable {
	//private static final long serialVersionUID = 5286826017132763759L;
	
	private String stringValue;
	private int intValue = 1;
	private double doubleValue;
	
	public String getStringValue() {
		return stringValue;
	}
	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}
	public int getIntValue() {
		return intValue;
	}
	public void setIntValue(int intValue) {
		this.intValue = intValue;
	}
	public double getDoubleValue() {
		return doubleValue;
	}
	public void setDoubleValue(double doubleValue) {
		this.doubleValue = doubleValue;
	}
	
	@Override 
	public String toString() {
        return format("Request received: '%s'.", stringValue);
    }
	

}
