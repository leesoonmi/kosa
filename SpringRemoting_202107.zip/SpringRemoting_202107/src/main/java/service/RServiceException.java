package service;

public class RServiceException extends Exception {

	private static final long serialVersionUID = -3442914439931322350L;

	public RServiceException() {
		super();
	}

	public RServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public RServiceException(String message) {
		super(message);
	}

	public RServiceException(Throwable cause) {
		super(cause);
	}

}
