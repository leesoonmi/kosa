package service;

public class InternalTeamRService implements RService {
	
	private BizDao bizDao = null;
	
	public void setBizDao(BizDao bizDao) {
		this.bizDao = bizDao;
		System.out.println("InternalTeamRService::setBizDao() called.");
	}

	public SerializableResponse processBizRequest(SerializableRequest b) throws RServiceException {
		
		System.out.println("InternalTeamRService::processBizRequest() called.");
		
		SerializableResponse result = null;
		
		int ii = b.getIntValue();
		
		
		try {
			System.out.println("++++++++++++++++++++++++++++++> Client transferred Value:"+ii);
			/*
			 * result = bizDao.getBizRequest(b);
			 * System.out.println("Processed Value:"+result.getrValue());
			 */
		} catch (Exception e) {
			throw new RServiceException("Internal request rejected: "+e);
		}
		
		return result;
	}
	
	/*
	@Override public Booking bookPickUp(String pickUpLocation) throws BookingException {
        if (random() < 0.3) throw new BookingException("Cab unavailable");
        return new Booking(randomUUID().toString());
    }
	 */

}
