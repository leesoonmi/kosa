package service;

import static java.lang.System.out;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean;
import org.springframework.remoting.httpinvoker.HttpInvokerServiceExporter;

//import com.sun.security.ntlm.Server;

@Configuration
@ComponentScan
@EnableAutoConfiguration
//@SpringBootApplication
//@ComponentScan("aa") //go to the top level
public class SpringRemotingApplication {
	
    @Bean(name = "/internal")
    HttpInvokerServiceExporter accountService() {
        HttpInvokerServiceExporter exporter = new HttpInvokerServiceExporter();
        exporter.setService( new InternalTeamRService() );
        exporter.setServiceInterface( RService.class );
        return exporter;
    }

   
    public static void main(String[] args)  {
        SpringApplication.run(SpringRemotingApplication.class, args);
        
        
    }
}
