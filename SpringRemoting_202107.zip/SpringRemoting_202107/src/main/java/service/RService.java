package service;

public interface RService {
	
	public SerializableResponse processBizRequest(SerializableRequest b)
			throws RServiceException;

}
