package service;

import java.io.Serializable;

public class SerializableResponse implements Serializable {

	
	//private static final long serialVersionUID = -5003200919966876725L;
	
	/////////////////////////////////////////////////////////////////////////
	//your domain VO
	private int rValue;

	public int getrValue() {
		return rValue;
	}

	public void setrValue(int rValue) {
		this.rValue = rValue;
	}
	

	

}
