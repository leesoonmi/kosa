package service;

public class InternalTeamBizDao implements BizDao {
	
	//private static final Log log = LogFactory.getLog(BizDaoImpl.class);

	public SerializableResponse getBizRequest(SerializableRequest b) 
			throws DAOException {
		SerializableResponse result = new SerializableResponse();

		/////////////////////////////////////////////////////////////////////////
		//your domain
		int intValue = b.getIntValue();
		System.out.println("InternalTeamBizDao::getBizRequest() intValue: "+intValue);
	
		if (intValue == 1) {
			result.setrValue(2);
			return result;
		}
		
		if (result == null) {
			throw new DAOException("Not in the database.");
		}
		/////////////////////////////////////////////////////////////////////////
		
		return result;
	}

}
